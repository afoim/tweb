New:
• Redesigned Profiles – enjoy new enhanced profile view.
• Anonymous Posting in Public Groups – tap the profile picture next to the message bar and choose one of your channels – the messages you send after that will appear with the name and photo of the channel instead of your personal account.
• Better navigation between folders – get back to the main folder by pressing the Escape button.

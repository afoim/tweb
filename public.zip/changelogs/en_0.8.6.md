• Added changelogs.
• Audio player improvements: seek, next/previous buttons, volume controls. Changing volume in the video player will affect audio as well.
• Fixed inability to delete multiple items from pending scheduled messages.
• Fixed accidentally deleting media messages after removing their captions.
• Fixed editing album captions.

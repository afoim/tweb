• Added support for new video stickers.

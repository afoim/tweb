• Application has been updated to support new 64-bit identifiers.
• Added Swipe-to-Reply on touchscreen devices
• Rebuilt Chat Folders – easily able to handle large chat lists.
• Added confirmation popups for logging out, cancelling a message edit.
• Fixed sending videos as a file.
• Document thumbnails now properly load when sending and forwarding.
• Media sent as a file now opens properly in the media viewer.
• Other bug fixes and improvements.

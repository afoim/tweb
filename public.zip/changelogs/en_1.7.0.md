🎄 Happy New Year to everyone! [WebK](http://web.telegram.org/k) launched its first update of 2023, adding a pack of features you can now enjoy on Web!

📚 [Topics 2.0](https://telegram.org/blog/ultimate-privacy-topics-2-0#topics-2-0)
Admins of **any group** can enable Topics, creating separate spaces within the group to discuss different subjects – with a sleek **two-column layout** to easily navigate chats.

😶‍🌫️ [Hidden Media](https://telegram.org/blog/hidden-media-zero-storage-profile-pics#hidden-media) 
Media hidden with a shimmering spoiler effect is properly displayed in the app – just tap or click to view the image. The next [WebK](http://web.telegram.org/k) update will allow you to send media with this spoiler effect.

🏴‍☠️ [No-SIM Signup and Login](https://telegram.org/blog/ultimate-privacy-topics-2-0#sign-up-without-a-sim-card) 
Users who have an **anonymous number** from [Fragment](https://fragment.com/numbers) can login to their existing account or create a **new account** with the number.

🔤 [Collectible Usernames](https://telegram.org/blog/topics-in-groups-collectible-usernames#collectible-usernames)  
Owners of collectible usernames can now **assign collectibles** to their personal account, groups or channels – and **manage** them within the app.

Lastly, the app also preserves your **history stack** – if you follow a [t.me](https://t.me) link to another message in a chat, you can return to the **first message** with the 🔽 button.

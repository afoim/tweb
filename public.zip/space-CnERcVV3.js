import{cC as e,t as n,bb as i,Z as o}from"./index-kKS_qFVJ.js";var p=n("<div>");function l(s){const[t,a]=e(s,["amount","withTransition"]);return(()=>{var r=p();return i(r,o(a,{get style(){return{"padding-top":t.amount,transition:t.withTransition?".2s":void 0}}}),!1,!1),r})()}export{l as S};
//# sourceMappingURL=space-CnERcVV3.js.map
